# Deprecated
Repository has been moved: https://gitlab.nemo.travel/frontend/flights.search.widget
