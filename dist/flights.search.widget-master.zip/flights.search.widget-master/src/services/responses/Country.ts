export interface CountryResponse {
	code: string;
	name: string;
	nameEn: string;
}
