import { AutocompleteSuggestion } from './AutocompleteSuggestion';

export interface AutocompleteOption {
	value: AutocompleteSuggestion;
	label: string;
}
