import { CityResponse } from '../responses/City';

export interface City extends CityResponse {
	test?: string;
}
