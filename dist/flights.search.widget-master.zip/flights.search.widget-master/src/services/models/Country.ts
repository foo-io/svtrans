import { CountryResponse } from '../responses/Country';

export interface Country extends CountryResponse {
	test?: string;
}
