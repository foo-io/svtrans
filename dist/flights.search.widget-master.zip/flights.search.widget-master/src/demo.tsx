import * as React from 'react';
import * as ReactDOM from 'react-dom';
import DemoForm from './components/Demo';

ReactDOM.render(
	<DemoForm/>,
	document.getElementById('root')
);
